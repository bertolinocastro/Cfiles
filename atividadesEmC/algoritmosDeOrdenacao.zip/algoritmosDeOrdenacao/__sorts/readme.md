#Pasta do sub-repo dos Algoritmos de Ordenação propriamente ditos

###Estruturação das pastas deve seguir o seguinte modelo:

1. Pasta do Vetor:  
  1. Arquivos principais;  
  2. Pasta com os arquivos principais desassemblados;  
2. Pasta da Lista:  
  1. Arquivos principais;  
  2. Pasta com os arquivos principais desassemblados;  

####A diferenciação entre Vetor e Lista (encadeada) se dá pela perfomance, em determinados casos, ao acesso de forma direta ou indireta às chaves pelo algoritmo de ordenação, visando demonstrar suas diferenças.