#Pasta de Debugs

###Pasta consiste em debugs indiscriminados

####*Debugs de memória serão feitos nesta pasta*