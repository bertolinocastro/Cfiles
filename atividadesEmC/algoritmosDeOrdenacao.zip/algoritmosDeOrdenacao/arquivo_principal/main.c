#include <stdio.h>
#include "populadores.h"
#ifndef HAVE_OWN_OPENGL_LIB_H
	#include "openGL.h"
#endif
#include "../__sorts/bubble_sort/modelo_vetor/bubble_sort.h"

int main( int argc , char **argv ){

	scanf( " %d" , &N );

	cria_janela( &argc , argv );

	return 0;
}











