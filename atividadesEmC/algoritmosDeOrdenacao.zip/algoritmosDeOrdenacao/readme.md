#Sub-repositório dedicado para o trabalho de Ordenação

###Estruturação consiste em:

1. Modelos de ordenação (algoritmos em si);  
2. Software central (irá executar todas as funcionalidades demonstráveis);  
3. Medições probabilísticas (medir funções e instruções de forma a achar sua tendência de tempo de execução);  
4. Debugs ();  